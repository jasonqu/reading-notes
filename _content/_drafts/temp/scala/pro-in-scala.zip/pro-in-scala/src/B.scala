import scala.io.Source

object B {

  def updateRecordByName(r: Symbol, value: Any) {
    // code goes here
  }

  def main(args: Array[String]) {
    updateRecordByName('favoriteAlbum, "OK Computer")
  }
}