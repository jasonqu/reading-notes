import scala.io.Source

object A {

  def main(args: Array[String]) {
    val width = 50
      new LongLines().processFile("""E:\Project\scala\study\pro-in-scala\src\A.scala""", width)
  }
}