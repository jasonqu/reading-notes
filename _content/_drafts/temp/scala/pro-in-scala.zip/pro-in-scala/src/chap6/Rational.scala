package chap6

class Rational(n: Int, d: Int) {
  override def toString = n +"/"+ d
}